echo "Creating Database Secrets"

aws secretsmanager create-secret \
	--name "terraform/db_credentials" \
	--secret-string '{"username":"admin","password":"SecurePass123!"}' \
	--region us-east-2 \
	--profile lab-sso

echo "Verifying Database Secrets"

aws secretsmanager get-secret-value \
	--secret-id "terraform/db_credentials" \
	--region us-east-2 \
	--profile lab-sso
