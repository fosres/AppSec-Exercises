# terraworkspace/terragrunt.hcl

remote_state {
	backend = "s3"
	generate = {
		path      = "backend.tf"
		if_exists = "overwrite"
	}
	config = {
		bucket       = "fosres-terraform-state"
		key          = "${path_relative_to_include()}/terraform.tfstate"
		region       = "us-east-2"
		encrypt      = true
		use_lockfile = true
	}
}

generate "provider" {
	if_exists = "overwrite"
	path      = "provider.tf"
	contents  = <<EOF
provider "aws" {
  region  = "us-east-2"
}
EOF
}

terraform {
	extra_arguments "upgrade" {
		commands  = ["init"]
		arguments = ["-upgrade"]
	}
}
