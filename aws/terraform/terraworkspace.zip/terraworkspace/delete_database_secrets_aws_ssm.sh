aws ssm delete-parameter \
	--name "/terraform/db_username" \
	--profile lab-sso --region us-east-2

aws ssm delete-parameter \
	--name "/terraform/db_password" \
	--profile lab-sso --region us-east-2

# Verify deletion
aws ssm get-parameter \
	--name "/terraform/db_username" \
	--profile lab-sso --region us-east-2

aws ssm get-parameter \
	--name "/terraform/db_password" \
	--profile lab-sso --region us-east-2

# 5. Delete Secrets Manager secret when fully done
aws secretsmanager delete-secret \
  --secret-id "terraform/db_credentials" \
  --force-delete-without-recovery \
  --region us-east-2 --profile lab-sso

# Verify Secrets Manager secret is fully deleted

aws secretsmanager describe-secret \
  --secret-id "terraform/db_credentials" \
  --region us-east-2 \
  --profile lab-sso
